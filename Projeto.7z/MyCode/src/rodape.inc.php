<div class="rodape">
    <hr>
    <center>
        <p>	
            <?php
            date_default_timezone_set("America/Sao_Paulo");
            $data = date("d/m/Y");
            $hora = date("H:i:s");
            echo "Acesso em: $data ás $hora";
            ?>
        Pedro Enju &copy; 2018
        </p>
    </center>
    <hr>
</div>
