<?php
	error_reporting (E_ALL & ~ E_NOTICE & ~ E_DEPRECATED);

	$base = "projetoppw";
	$user = "root"; 
	$pass = "";
	$host = "localhost";
?>
